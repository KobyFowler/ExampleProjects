package com.androidfactory.fakestore.model.ui

data class UiProductInCart(
    val uiProduct: UiProduct,
    val quantity: Int = 1
)
