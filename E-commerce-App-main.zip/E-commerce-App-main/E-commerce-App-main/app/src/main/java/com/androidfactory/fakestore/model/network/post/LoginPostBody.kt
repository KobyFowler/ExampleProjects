package com.androidfactory.fakestore.model.network.post

data class LoginPostBody(val username: String, val password: String)
