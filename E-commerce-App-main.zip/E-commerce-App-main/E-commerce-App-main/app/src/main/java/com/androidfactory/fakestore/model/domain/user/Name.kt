package com.androidfactory.fakestore.model.domain.user

data class Name(val firstname: String, val lastname: String)